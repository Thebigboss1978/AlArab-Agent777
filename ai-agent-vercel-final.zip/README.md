# AI Agent Club 777 🚀

## Run locally
```bash
chmod +x start.sh
./start.sh
```

## Deploy on Vercel
1. Push this repo to GitHub
2. Import into Vercel
3. Deploy 🚀
